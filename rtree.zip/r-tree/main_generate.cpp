// main_generate.cpp
#include "RTree.h"
#include <cstdlib> // system
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

int main() {
  // Directorio de salida basado en MAXNODES
  string outdir = string("outputs/MAXNODES_") + to_string(MAXNODES);
  string cmd = "mkdir -p " + outdir;
  system(cmd.c_str());

  // Configuración
  const int Nsteps = 40;         // cantidad de inserciones
  vector<int> sizes = {2, 3, 4}; // tamaños de polígonos

  // RNG reproducible
  std::mt19937 rng(123456);
  std::uniform_int_distribution<int> dist(0, 100);

  RTree rtree;
  vector<vector<pair<int, int>>> vpoints; // todos los objetos acumulados

  for (int step = 0; step < Nsteps; ++step) {
    // Generar polígono de tamaño variable
    int k = sizes[step % sizes.size()];
    vector<pair<int, int>> poly;
    for (int j = 0; j < k; ++j) {
      int x = dist(rng);
      int y = dist(rng);
      poly.emplace_back(x, y);
    }
    vpoints.push_back(poly);

    // Calcular MBR e insertar
    Rect rect = rtree.MBR(poly);
    rtree.Insert(rect.m_min, rect.m_max, poly);

    // Obtener MBRs del árbol por nivel
    vector<vector<vector<pair<int, int>>>> objects_n;
    rtree.getMBRs(objects_n);

    // Serializar a JSON
    ostringstream oss;
    oss << "{\n";

    // Todos los puntos acumulados
    oss << "  \"all_points\": [";
    for (size_t oi = 0; oi < vpoints.size(); ++oi) {
      for (size_t pj = 0; pj < vpoints[oi].size(); ++pj) {
        oss << "[" << vpoints[oi][pj].first << "," << vpoints[oi][pj].second
            << "]";
        if (!(oi == vpoints.size() - 1 && pj == vpoints[oi].size() - 1))
          oss << ",";
      }
    }
    oss << "],\n";

    // MBR del objeto recién insertado
    oss << "  \"mbr\": [" << rect.m_min[0] << "," << rect.m_min[1] << ","
        << rect.m_max[0] << "," << rect.m_max[1] << "],\n";

    // MBRs del árbol por nivel
    oss << "  \"tree\": [\n";
    for (size_t lev = 0; lev < objects_n.size(); ++lev) {
      oss << "    [\n";
      for (size_t idx = 0; idx < objects_n[lev].size(); ++idx) {
        auto &q = objects_n[lev][idx];
        oss << "      [[ " << q[0].first << "," << q[0].second << "], [ "
            << q[1].first << "," << q[1].second << "]]";
        if (idx + 1 < objects_n[lev].size())
          oss << ",";
        oss << "\n";
      }
      oss << "    ]";
      if (lev + 1 < objects_n.size())
        oss << ",";
      oss << "\n";
    }
    oss << "  ]\n";
    oss << "}\n";

    // Guardar archivo
    char filename[512];
    sprintf(filename, "%s/step_%02d.json", outdir.c_str(), step + 1);
    ofstream ofs(filename);
    ofs << oss.str();
    ofs.close();

    cout << "Wrote " << filename << " (inserted poly size=" << k << ")\n";
  }

  cout << "Finished. JSON files are in: " << outdir << endl;
  return 0;
}
